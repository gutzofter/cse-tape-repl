# Device notes
